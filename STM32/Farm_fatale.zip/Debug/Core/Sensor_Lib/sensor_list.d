Core/Sensor_Lib/sensor_list.o: ../Core/Sensor_Lib/sensor_list.c \
 C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib/sensor_list.h
C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib/sensor_list.h:
