################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Sensor_Lib/DS18B20/ds18b20.c \
../Core/Sensor_Lib/DS18B20/ds18b20_custom.c \
../Core/Sensor_Lib/DS18B20/ow.c 

OBJS += \
./Core/Sensor_Lib/DS18B20/ds18b20.o \
./Core/Sensor_Lib/DS18B20/ds18b20_custom.o \
./Core/Sensor_Lib/DS18B20/ow.o 

C_DEPS += \
./Core/Sensor_Lib/DS18B20/ds18b20.d \
./Core/Sensor_Lib/DS18B20/ds18b20_custom.d \
./Core/Sensor_Lib/DS18B20/ow.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Sensor_Lib/DS18B20/%.o Core/Sensor_Lib/DS18B20/%.su Core/Sensor_Lib/DS18B20/%.cyclo: ../Core/Sensor_Lib/DS18B20/%.c Core/Sensor_Lib/DS18B20/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I"C:/workspace/ARM/Farm_fatale/Core/Farm_Lib" -I"C:/workspace/ARM/Farm_fatale/Core/My_Lib" -I"C:/workspace/ARM/Farm_fatale/Core/My_Lib/GPIO" -I"C:/workspace/ARM/Farm_fatale/Core/My_Lib/Uart" -I"C:/workspace/ARM/Farm_fatale/Core/My_Lib/Value" -I"C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib" -I"C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib/ADC_Sensor" -I"C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib/BH1750" -I"C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib/DS18B20" -I"C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib/Flow" -I"C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib/SHT31" -I"C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib/Step_Motor" -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Sensor_Lib-2f-DS18B20

clean-Core-2f-Sensor_Lib-2f-DS18B20:
	-$(RM) ./Core/Sensor_Lib/DS18B20/ds18b20.cyclo ./Core/Sensor_Lib/DS18B20/ds18b20.d ./Core/Sensor_Lib/DS18B20/ds18b20.o ./Core/Sensor_Lib/DS18B20/ds18b20.su ./Core/Sensor_Lib/DS18B20/ds18b20_custom.cyclo ./Core/Sensor_Lib/DS18B20/ds18b20_custom.d ./Core/Sensor_Lib/DS18B20/ds18b20_custom.o ./Core/Sensor_Lib/DS18B20/ds18b20_custom.su ./Core/Sensor_Lib/DS18B20/ow.cyclo ./Core/Sensor_Lib/DS18B20/ow.d ./Core/Sensor_Lib/DS18B20/ow.o ./Core/Sensor_Lib/DS18B20/ow.su

.PHONY: clean-Core-2f-Sensor_Lib-2f-DS18B20

