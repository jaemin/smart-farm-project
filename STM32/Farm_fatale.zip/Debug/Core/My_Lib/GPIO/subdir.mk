################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/My_Lib/GPIO/My_ARM_RTOS_GPIO_Lib_V4_1.c 

OBJS += \
./Core/My_Lib/GPIO/My_ARM_RTOS_GPIO_Lib_V4_1.o 

C_DEPS += \
./Core/My_Lib/GPIO/My_ARM_RTOS_GPIO_Lib_V4_1.d 


# Each subdirectory must supply rules for building sources it contributes
Core/My_Lib/GPIO/%.o Core/My_Lib/GPIO/%.su Core/My_Lib/GPIO/%.cyclo: ../Core/My_Lib/GPIO/%.c Core/My_Lib/GPIO/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I"C:/workspace/ARM/Farm_fatale/Core/Farm_Lib" -I"C:/workspace/ARM/Farm_fatale/Core/My_Lib" -I"C:/workspace/ARM/Farm_fatale/Core/My_Lib/GPIO" -I"C:/workspace/ARM/Farm_fatale/Core/My_Lib/Uart" -I"C:/workspace/ARM/Farm_fatale/Core/My_Lib/Value" -I"C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib" -I"C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib/ADC_Sensor" -I"C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib/BH1750" -I"C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib/DS18B20" -I"C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib/Flow" -I"C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib/SHT31" -I"C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib/Step_Motor" -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-My_Lib-2f-GPIO

clean-Core-2f-My_Lib-2f-GPIO:
	-$(RM) ./Core/My_Lib/GPIO/My_ARM_RTOS_GPIO_Lib_V4_1.cyclo ./Core/My_Lib/GPIO/My_ARM_RTOS_GPIO_Lib_V4_1.d ./Core/My_Lib/GPIO/My_ARM_RTOS_GPIO_Lib_V4_1.o ./Core/My_Lib/GPIO/My_ARM_RTOS_GPIO_Lib_V4_1.su

.PHONY: clean-Core-2f-My_Lib-2f-GPIO

