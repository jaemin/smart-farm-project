################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/Farm_Lib/message.c \
../Core/Farm_Lib/sensor_list.c \
../Core/Farm_Lib/sensor_write.c 

OBJS += \
./Core/Farm_Lib/message.o \
./Core/Farm_Lib/sensor_list.o \
./Core/Farm_Lib/sensor_write.o 

C_DEPS += \
./Core/Farm_Lib/message.d \
./Core/Farm_Lib/sensor_list.d \
./Core/Farm_Lib/sensor_write.d 


# Each subdirectory must supply rules for building sources it contributes
Core/Farm_Lib/%.o Core/Farm_Lib/%.su Core/Farm_Lib/%.cyclo: ../Core/Farm_Lib/%.c Core/Farm_Lib/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F446xx -c -I"C:/workspace/ARM/Farm_fatale/Core/Farm_Lib" -I"C:/workspace/ARM/Farm_fatale/Core/My_Lib" -I"C:/workspace/ARM/Farm_fatale/Core/My_Lib/GPIO" -I"C:/workspace/ARM/Farm_fatale/Core/My_Lib/Uart" -I"C:/workspace/ARM/Farm_fatale/Core/My_Lib/Value" -I"C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib" -I"C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib/ADC_Sensor" -I"C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib/BH1750" -I"C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib/DS18B20" -I"C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib/Flow" -I"C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib/SHT31" -I"C:/workspace/ARM/Farm_fatale/Core/Sensor_Lib/Step_Motor" -I../Core/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc -I../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32F4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-Farm_Lib

clean-Core-2f-Farm_Lib:
	-$(RM) ./Core/Farm_Lib/message.cyclo ./Core/Farm_Lib/message.d ./Core/Farm_Lib/message.o ./Core/Farm_Lib/message.su ./Core/Farm_Lib/sensor_list.cyclo ./Core/Farm_Lib/sensor_list.d ./Core/Farm_Lib/sensor_list.o ./Core/Farm_Lib/sensor_list.su ./Core/Farm_Lib/sensor_write.cyclo ./Core/Farm_Lib/sensor_write.d ./Core/Farm_Lib/sensor_write.o ./Core/Farm_Lib/sensor_write.su

.PHONY: clean-Core-2f-Farm_Lib

