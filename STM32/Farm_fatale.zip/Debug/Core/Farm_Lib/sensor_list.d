Core/Farm_Lib/sensor_list.o: ../Core/Farm_Lib/sensor_list.c \
 C:/workspace/ARM/Farm_fatale/Core/Farm_Lib/sensor_list.h
C:/workspace/ARM/Farm_fatale/Core/Farm_Lib/sensor_list.h:
