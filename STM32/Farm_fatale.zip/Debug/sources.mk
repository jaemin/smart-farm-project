################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

ELF_SRCS := 
OBJ_SRCS := 
S_SRCS := 
C_SRCS := 
S_UPPER_SRCS := 
O_SRCS := 
CYCLO_FILES := 
OBJCOPY_HEX := 
SIZE_OUTPUT := 
OBJDUMP_LIST := 
SU_FILES := 
EXECUTABLES := 
OBJS := 
MAP_FILES := 
S_DEPS := 
S_UPPER_DEPS := 
C_DEPS := 
OBJCOPY_BIN := 

# Every subdirectory with source files must be described here
SUBDIRS := \
Core/Farm_Lib \
Core/My_Lib/GPIO \
Core/My_Lib/Uart \
Core/My_Lib/Value \
Core/Sensor_Lib/ADC_Sensor \
Core/Sensor_Lib/BH1750 \
Core/Sensor_Lib/DS18B20 \
Core/Sensor_Lib/Flow \
Core/Sensor_Lib/SHT31 \
Core/Sensor_Lib/Step_Motor \
Core/Src \
Core/Startup \
Drivers/STM32F4xx_HAL_Driver/Src \

