/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define MOTOR_IN1_Pin GPIO_PIN_0
#define MOTOR_IN1_GPIO_Port GPIOC
#define MOTOR_IN2_Pin GPIO_PIN_1
#define MOTOR_IN2_GPIO_Port GPIOC
#define MOTOR_IN3_Pin GPIO_PIN_2
#define MOTOR_IN3_GPIO_Port GPIOC
#define MOTOR_IN4_Pin GPIO_PIN_3
#define MOTOR_IN4_GPIO_Port GPIOC
#define FIRE_DO_Pin GPIO_PIN_0
#define FIRE_DO_GPIO_Port GPIOA
#define FIRE_AO_Pin GPIO_PIN_1
#define FIRE_AO_GPIO_Port GPIOA
#define USART_RX_Pin GPIO_PIN_3
#define USART_RX_GPIO_Port GPIOA
#define PH_AO_Pin GPIO_PIN_4
#define PH_AO_GPIO_Port GPIOA
#define LED_Pin GPIO_PIN_5
#define LED_GPIO_Port GPIOA
#define TDS_AO_Pin GPIO_PIN_6
#define TDS_AO_GPIO_Port GPIOA
#define GAS_AO_Pin GPIO_PIN_7
#define GAS_AO_GPIO_Port GPIOA
#define WARN_Pin GPIO_PIN_4
#define WARN_GPIO_Port GPIOC
#define FLOAT_Pin GPIO_PIN_5
#define FLOAT_GPIO_Port GPIOC
#define FAN_Pin GPIO_PIN_1
#define FAN_GPIO_Port GPIOB
#define GAS_DO_Pin GPIO_PIN_2
#define GAS_DO_GPIO_Port GPIOB
#define DS18B20_Pin GPIO_PIN_8
#define DS18B20_GPIO_Port GPIOC
#define WATERPUMP_Pin GPIO_PIN_9
#define WATERPUMP_GPIO_Port GPIOC
#define FLOW_Pin GPIO_PIN_8
#define FLOW_GPIO_Port GPIOA
#define FLOW_EXTI_IRQn EXTI9_5_IRQn
#define TCK_Pin GPIO_PIN_14
#define TCK_GPIO_Port GPIOA
#define SWO_Pin GPIO_PIN_3
#define SWO_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
