/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dma.h"
#include "i2c.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
// sys lib
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// my lib
#include <My_ARM_RTOS_Value_Lib_V1_4.h>
#include <My_ARM_RTOS_UART_Lib_V5_2.h>

// prj lib
#include <sensor_list.h>
#include <ds18b20_custom.h>
#include <sht31.h>
#include <bh1750.h>
#include <flow.h>
#include <adc_sensor.h>
#include <step_motor.h>
#include <sensor_range.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

//#define DEBUG1	1			// debug용 여러 값 출력 확인용

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

const char* str_actuator = "actuator";
const char* split_str = "&$";
int8_t step_phase = 0;
uint8_t step_dir = 0;
uint16_t motor_count = 0;

extern DMA_HandleTypeDef hdma_usart6_rx;

float temp_range[minmax] = { 18.0, 28.0 };		// 관리자 설정 기본 온도 설정 범위
uint16_t humi_range[minmax] = { 50, 70 };		// 관리자 설정 기본 습도 설정 범위
uint16_t luxv_range[minmax] = { 800, 2000 };	// 관리자 설정 기본 조도 설정 범위

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_NVIC_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
	char recvMsg[200];
	fg->run_flag = 0;
	fg->tm_flag = 0;
	char* msg1;
	char* msg2;
	char* msg3;

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_I2C1_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();
  MX_TIM6_Init();
  MX_USART6_UART_Init();
  MX_TIM4_Init();

  /* Initialize interrupts */
  MX_NVIC_Init();
  /* USER CODE BEGIN 2 */
  HAL_ADC_Start_DMA(&hadc1, (uint32_t*)adc_buf, 4);

  HAL_TIM_Base_Start_IT(&htim2);	// 수온센서

  // 수온센서 (DS18B20) 초기화
  ds18b20_init_set();

  // 액추에이터 상태 및 센서 범위 받아오기
  HAL_UART_Transmit_IT(&huart6, str_actuator, strlen(str_actuator));

  // DMA - Normal - IDLE 수신
  __HAL_UART_CLEAR_FLAG(&huart6, UART_FLAG_IDLE);
  __HAL_UART_ENABLE_IT(&huart6, UART_IT_IDLE);
  HAL_UARTEx_ReceiveToIdle_DMA(&huart6, &rx_d -> Rx_data_6, 200);
  __HAL_DMA_DISABLE_IT(&hdma_usart6_rx, DMA_IT_HT);
  huart6.hdmarx->Instance->CR &= ~DMA_SxCR_HTIE; // 최초 호출 시에도 HT 인터럽트 차단!

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  // 1분 타이머, 6초마다 동작
	  if (fg->tm_flag == 1) {
#ifdef DEBUG1
		  printf("loop : %d \r\n", tm->min);
#endif
		  SHT31_Read();			// 온습도센서
		  BH1750_Read();		// 조도센서
		  ds18b20_get();		// 수온센서
		  flow_read();			// 유량센서
		  adc_sensor_read();	// 불꽃센서, pH센서, TDS센서, Gas센서

		  fg->tm_flag = 0;
		  tm->min++;

		  if (tm->min == average_count){
			  sensor_write();
			  tm->min = 0;
		  }
#ifdef DEBUG1
		  printf("float switch : %d\r\n", HAL_GPIO_ReadPin(FLOAT_GPIO_Port, FLOAT_Pin));
#endif
		  // 워터펌프 OFF
		  if (HAL_GPIO_ReadPin(FLOAT_GPIO_Port, FLOAT_Pin)) {
			  // 워터펌프 ON인 경우 OFF으로 변경
			  if (HAL_GPIO_ReadPin(WATERPUMP_GPIO_Port, WATERPUMP_Pin) == 0) {
				  char* msg = "[PUMP]9,0&";
				  HAL_GPIO_WritePin(WATERPUMP_GPIO_Port, WATERPUMP_Pin, 1);
				  HAL_UART_Transmit(&huart6, msg, strlen(msg), 1000);
			  }
		  }
		  // 워터펌프 ON
		  else {
			  // 워터펌프 OFF인 경우 ON으로 변경
			  if (HAL_GPIO_ReadPin(WATERPUMP_GPIO_Port, WATERPUMP_Pin) == 1){
				  char* msg = "[PUMP]9,1&";
				  HAL_GPIO_WritePin(WATERPUMP_GPIO_Port, WATERPUMP_Pin, 0);
				  HAL_UART_Transmit(&huart6, msg, strlen(msg), 1000);
			  }
		  }
	  }

	  // ESP32에서 수신된 데이터가 있는 경우 동작
	  if (rx_flag -> rx_end_flag_6 == 1) {
#ifdef DEBUG1
		  printf("[ESP32 -> STM32] %s\r\n", rx_d->Rx_data_6);
#endif
		  strcpy(recvMsg, rx_d->Rx_data_6);

		  msg1 = strtok(recvMsg, split_str);

		  while(msg1 != NULL) {
			  // 액추에이터 데이터
			  if (strcmp(msg1, "a") == 0) {
				  msg1 = strtok(NULL, split_str);
				  msg2 = strtok(NULL, split_str);

				  uint8_t actuator = atoi(msg1);
				  uint8_t value = atoi(msg2);
#ifdef DEBUG1
				  printf("actuator : %d, value : %d\r\n", actuator, value);
#endif
				  switch(actuator){
					  case 9:		// fan
						HAL_GPIO_WritePin(FAN_GPIO_Port, FAN_Pin, !value);
						  break;
					  case 10:		// curtain
						  fg->run_flag = 1;
						  step_dir = value;
#ifdef DEBUG1
						  printf("CURTAIN value : %d, step_dir : %d\r\n", value, step_dir);
#endif
						  break;
					  case 11:		// led
						HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, !value);
						  break;
					  case 13:		// alart
					    HAL_GPIO_WritePin(WARN_GPIO_Port, WARN_Pin, !value);
						  break;
				  }
				  msg1 = strtok(NULL, split_str);
			  }
			  // 센서 데이터
			  else {
				  msg1 = strtok(NULL, split_str);
				  msg2 = strtok(NULL, split_str);
				  msg3 = strtok(NULL, split_str);

				  uint8_t sensor = atoi(msg1);
				  float min = atof(msg2);
				  float max = atof(msg3);

				  switch(sensor) {
					  case 1:
						  temp_range[0] = min;
						  temp_range[1] = max;
						  break;
					  case 2:
						  humi_range[0] = min;
						  humi_range[1] = max;
						  break;
					  case 3:
						  luxv_range[0] = min;
						  luxv_range[1] = max;
						  break;
				  }
#ifdef DEBUG1
				  printf("sensor : %d, min : %f, max : %f\r\n", sensor, min, max);
#endif
				  msg1 = strtok(NULL, split_str);
			  }
		  }
		  memset(rx_d->Rx_data_6, 0, sizeof(uint8_t)*200);
		  rx_flag -> rx_end_flag_6 = 0;
	  }

	  // 커튼 ON/OFF 신호가 있을 때마다 동작
	  if (fg->run_flag == 1) {
		  stepper_run();
	  }

	  // 커튼 모터 움직임 제어
	  if (fg->IRQ_Flag == 1) {
		  if (step_dir) step_phase++;
		  else          step_phase--;

		  if (step_phase > 7) step_phase = 0;
		  if (step_phase < 0) step_phase = 7;

		  motor_count++;
		  stepper_control(step_phase);
		  fg->IRQ_Flag = 0;
	  }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 90;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief NVIC Configuration.
  * @retval None
  */
static void MX_NVIC_Init(void)
{
  /* TIM6_DAC_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(TIM6_DAC_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(TIM6_DAC_IRQn);
  /* TIM2_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(TIM2_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(TIM2_IRQn);
  /* DMA2_Stream0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);
  /* TIM4_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(TIM4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(TIM4_IRQn);
  /* USART6_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(USART6_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(USART6_IRQn);
  /* DMA2_Stream1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream1_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream1_IRQn);
  /* EXTI9_5_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);
}

/* USER CODE BEGIN 4 */
void HAL_TIM_PeriodElapsedCallback (TIM_HandleTypeDef* htim) {
	if (htim->Instance == TIM2) {
		fg->tm_flag = 1;
	}

	if (htim->Instance == TIM4)
	{
		fg->IRQ_Flag = 1;
	}
}
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
