/*
 * message.c
 *
 *  Created on: Sep 30, 2026
 *      Author: PC
 */

#include <message.h>

char recvMsg[20];
char* msg1, msg2, actuator_str, value_str;
uint8_t actuator, value;

void message_split(uint8_t* data[20]){
	strcpy(recvMsg, data);

    msg1 = strtok(recvMsg, "&");
    msg2 = strtok(NULL, "&");

    actuator_str = strtok(msg1, "=");
    actuator_str = strtok(NULL, "=");
    actuator = atoi(actuator_str);

    value_str = strtok(msg2, "=");
    value_str = strtok(NULL, "=");
    value = atoi(value_str);

    printf("actuator : %d\r\n", actuator);
    printf("value : %d\r\n", value);
}
