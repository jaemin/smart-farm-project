/*
 * sensor_range.h
 *
 *  Created on: Oct 1, 2026
 *      Author: Jaemin Joo
 */

#ifndef FARM_LIB_SENSOR_RANGE_H_
#define FARM_LIB_SENSOR_RANGE_H_

#include <string.h>
#include <main.h>
#include <stdint.h>

#define minmax	2
#define temp_value_range	1
#define humi_value_range	3
#define luxv_value_range	50

extern float temp_range[minmax];
extern uint16_t humi_range[minmax];
extern uint16_t luxv_range[minmax];

#endif /* FARM_LIB_SENSOR_RANGE_H_ */
