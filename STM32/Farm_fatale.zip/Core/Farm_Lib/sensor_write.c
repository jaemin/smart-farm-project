/*
 * sensor_write.c
 *
 *  Created on: Sep 23, 2026
 *      Author: Jaemin Joo
 */

#include <sensor_write.h>

uint8_t buf[50];
uint8_t temp_fan_flag = 0;
uint8_t humi_fan_flag = 0;
uint8_t temp_curt_flag = 0;

void sensor_write_float(float result, int number) {
	sprintf(buf, "[%s]%.2f&", sensor[number], result);
	HAL_UART_Transmit(&huart6, buf, strlen(buf), 1000);
	printf("%s\r\n", buf);
}

void sensor_write_int(uint16_t result, int number) {
	sprintf(buf, "[%s]%d&", sensor[number], result);
	HAL_UART_Transmit(&huart6, buf, strlen(buf), 1000);
	printf("%s\r\n", buf);
}

void sensor_write() {
	float avg_t = 0;
	uint16_t avg_h = 0, avg_l = 0;
#ifdef DEBUG1
		printf(" ===== temp ===== \r\n");
#endif
	avg_t = sensor_average_float(temp_list);
	change_actuator_temp(avg_t);
	sensor_write_float(avg_t, temp);

#ifdef DEBUG1
		printf(" ===== humi ===== \r\n");
#endif
	avg_h = sensor_average_int(humi_list);
	sensor_write_int(avg_h, humi);

#ifdef DEBUG1
		printf(" ===== luxv ===== \r\n");
#endif
	avg_l = sensor_average_int(luxv_list);
	change_actuator_humi_luxv(avg_h, avg_l);
	sensor_write_int(avg_l, luxv);

#ifdef DEBUG1
		printf(" ===== watp ===== \r\n");
#endif
	sensor_write_float(sensor_average_float(watp_list), watp);
#ifdef DEBUG1
		printf(" ===== flow ===== \r\n");
#endif
	sensor_write_float(sensor_average_float(flow_list), flow);
#ifdef DEBUG1
		printf(" ===== phvl ===== \r\n");
#endif
	sensor_write_float(sensor_average_float(phvl_list), phvl);
#ifdef DEBUG1
		printf(" ===== tdsv ===== \r\n");
#endif
	sensor_write_int(sensor_average_int(tdsv_list), tdsv);
#ifdef DEBUG1
		printf(" ===== flam ===== \r\n");
#endif
	sensor_write_int(sensor_average_int(flam_list), flam);
#ifdef DEBUG1
		printf(" ===== gasd ===== \r\n");
#endif
	sensor_write_int(sensor_average_int(gasd_list), gasd);
}

void change_actuator_temp(float avg) {
#ifdef DEBUG1
		printf("TEMP min : %.2f, max : %.2f\r\n", temp_range[0], temp_range[1]);
#endif
	// 온도가 적정범위 이하
	if (avg <= temp_range[0] + temp_value_range) {
#ifdef DEBUG1
		printf("LOW TEMP\r\n");
#endif
		// FAN이 ON인 경우, FAN OFF
		temp_fan_flag = 0;

		// 커튼이 OFF인 경우, 커튼 ON
		temp_curt_flag = 1;
	}
	// 온도가 적정범위 이상
	else if (temp_range[1] - temp_value_range <= avg) {
#ifdef DEBUG1
		printf("HIGH TEMP\r\n");
		printf("temp range [1] = %.2f\r\n", temp_range[1]);
		printf("temp value range = %d\r\n", temp_value_range);
#endif
		// FAN이 OFF인 경우, FAN ON
		temp_fan_flag = 1;

		// 커튼이 OFF인 경우, 커튼 ON
		temp_curt_flag = 1;
	}
	// 온도가 적정범위 이내
	else {
#ifdef DEBUG1
		printf("NORMAL TEMP\r\n");
#endif
		// FAN이 ON인 경우, FAN OFF
		temp_fan_flag = 0;

		temp_curt_flag = 0;

		// 커튼이 ON, 커튼 OFF
		if (step_dir == 1 && fg->run_flag == 0) {
			char* msg = "[CURT]3,0&";
			fg->run_flag = 1;
			step_dir = 0;
			HAL_UART_Transmit(&huart6, msg, strlen(msg), 1000);
		}
	}
}

void change_actuator_humi_luxv(uint16_t avg_h, uint16_t avg_l) {
#ifdef DEBUG1
	printf("HUMI min : %d, max : %d\r\n", humi_range[0], humi_range[1]);
	printf("LUXV min : %d, max : %d\r\n", luxv_range[0], luxv_range[1]);
#endif
	// 습도가 적정범위 이하
	if (avg_h <= humi_range[0] + humi_value_range) {
	#ifdef DEBUG1
		printf("LOW HUMIDITY\r\n");
	#endif
		// FAN이 ON인 경우, FAN OFF
		humi_fan_flag = 0;
	}
	// 습도가 적정범위 이상
	else if (humi_range[1] - humi_value_range <= avg_h) {
	#ifdef DEBUG1
		printf("HIGH HUMIDITY\r\n");
	#endif
		// FAN이 OFF인 경우, FAN ON
		humi_fan_flag = 1;
	}
	// 습도가 적정범위 이내
	else {
	#ifdef DEBUG1
		printf("NORMAL HUMIDITY\r\n");
	#endif
		// FAN이 ON인 경우, FAN OFF
		humi_fan_flag = 0;
	}

	// FAN이 ON 되어야 하는 경우
	if (temp_fan_flag || humi_fan_flag) {
		// FAN이 OFF인 경우
		if (HAL_GPIO_ReadPin(FAN_GPIO_Port, FAN_Pin) == 1) {
			char* msg;
			if (temp_fan_flag) {
				msg = "[FAN_]1,1&";
			}
			if (humi_fan_flag) {
				msg = "[FAN_]2,1&";
			}

			HAL_GPIO_WritePin(FAN_GPIO_Port, FAN_Pin, 0);
			HAL_UART_Transmit(&huart6, msg, strlen(msg), 1000);
		}
	}
	// FAN이 OFF 되어야 하는 경우
	else {
		// FAN이 ON인 경우
		if (HAL_GPIO_ReadPin(FAN_GPIO_Port, FAN_Pin) == 0) {
			char* msg = "[FAN_]2,0&";
			HAL_GPIO_WritePin(FAN_GPIO_Port, FAN_Pin, 1);
			HAL_UART_Transmit(&huart6, msg, strlen(msg), 1000);
		}
	}

	// 조도가 적정범위 이하
	if (avg_l <= luxv_range[0] + luxv_value_range) {
#ifdef DEBUG1
		printf("LOW LUX\r\n");
#endif
		// LED가 OFF, LED ON
		if (HAL_GPIO_ReadPin(LED_GPIO_Port, LED_Pin) == 1) {
			char* msg = "[LED_]3,1&";
			HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, 0);
			HAL_UART_Transmit(&huart6, msg, strlen(msg), 1000);
		}

		if (!temp_curt_flag) {
			// 커튼이 ON, 커튼 OFF
			if (step_dir == 1 && fg->run_flag == 0) {
				char* msg = "[CURT]3,0&";
				fg->run_flag = 1;
				step_dir = 0;
				HAL_UART_Transmit(&huart6, msg, strlen(msg), 1000);
			}
		}
	}
	// 조도가 적정범위 이상
	else if (luxv_range[1] - luxv_value_range <= avg_l) {
#ifdef DEBUG1
		printf("HIGH LUX\r\n");
#endif
		// 고온 + 고조도인 경우
		if (temp_curt_flag) {
			// 커튼이 OFF, 커튼 ON
			if (step_dir == 0 && fg->run_flag == 0) {
				char* msg = "[CURT]3,1&";
				fg->run_flag = 1;
				step_dir = 1;
				HAL_UART_Transmit(&huart6, msg, strlen(msg), 1000);
			}
		}
		// 저온 + 고조도인 경우
		else {
			// 커튼이 ON, 커튼 OFF
			if (step_dir == 1 && fg->run_flag == 0) {
				char* msg = "[CURT]3,0&";
				fg->run_flag = 1;
				step_dir = 0;
				HAL_UART_Transmit(&huart6, msg, strlen(msg), 1000);
			}
		}

		// LED가 ON, LED OFF
		if (HAL_GPIO_ReadPin(LED_GPIO_Port, LED_Pin) == 0) {
			char* msg = "[LED_]3,0&";
			HAL_GPIO_WritePin(LED_GPIO_Port, LED_Pin, 1);
			HAL_UART_Transmit(&huart6, msg, strlen(msg), 1000);
		}
	}
	// 조도가 적정범위 이내
	else {
#ifdef DEBUG1
		printf("NORMAL LUX\r\n");
#endif
		if (!temp_curt_flag) {
			// 커튼이 ON, 커튼 OFF
			if (step_dir == 1 && fg->run_flag == 0) {
				char* msg = "[CURT]3,0&";
				fg->run_flag = 1;
				step_dir = 0;
				HAL_UART_Transmit(&huart6, msg, strlen(msg), 1000);
			}
		}
	}
}

// 센서 데이터의 평균
float sensor_average_float(float* result) {
	uint8_t min = 0;
	uint8_t max = 0;
	float total = 0;
	uint8_t exception_count = 0;

	for(int i = 0 ; i < average_count ; i++) {
		if (result[min] > result[i]) {
			min = i;
		}
		if (result[max] < result[i]) {
			max = i;
		}
#ifdef DEBUG1
		printf("%d : %f\r\n", i, result[i]);
#endif
	}

	// 센서값의 최솟값과 최댓값 (이상치 제거용)을 제외한 값을 평균으로 내어 DB에 저장
	for(int i = 0 ; i < average_count ; i++) {
		if (i == min || i == max) {
#ifdef DEBUG1
		printf("min or max = %f\r\n", result[i]);
#endif
			exception_count++;
			continue;
		}
		else {
			total += result[i];
		}
	}
#ifdef DEBUG1
		printf("average = %f\r\n", total / (average_count - exception_count));
#endif
	return total / (average_count - exception_count);
}

uint16_t sensor_average_int(uint16_t* result) {
	uint8_t min = 0;
	uint8_t max = 0;
	int total = 0;
	uint8_t exception_count = 0;

	for(int i = 0 ; i < average_count ; i++) {
		if (result[min] > result[i]) {
			min = i;
		}
		if (result[max] < result[i]) {
			max = i;
		}
#ifdef DEBUG1
		printf("%d : %d\r\n", i, result[i]);
#endif
	}

	// 센서값의 최솟값과 최댓값 (이상치 제거용)을 제외한 값을 평균으로 내어 DB에 저장
	for(int i = 0 ; i < average_count ; i++) {
		if (i == min || i == max) {
#ifdef DEBUG1
		printf("min or max = %d\r\n", result[i]);
#endif
			exception_count++;
			continue;
		}
		else {
			total += result[i];
		}
	}
#ifdef DEBUG1
		printf("average = %d\r\n", total / (average_count - exception_count));
#endif
	return total / (average_count - exception_count);
}
