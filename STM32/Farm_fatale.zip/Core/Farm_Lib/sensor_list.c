/*
 * sensor_list.c
 *
 *  Created on: Sep 23, 2026
 *      Author: Jaemin Joo
 */

#include <sensor_list.h>

const char sensor[10][5] = {
		"TEMP",
		"HUMI",
		"LUXV",
		"WATP",
		"FLOW",
		"LEVL",
		"PHVL",
		"TDSV",
		"GASD",
		"FLAM"
};

float temp_list[average_count] = {0, };
uint16_t humi_list[average_count] = {0, };
uint16_t luxv_list[average_count] = {0, };
float watp_list[average_count] = {0, };
float flow_list[average_count] = {0, };
float levl_list[average_count] = {0, };
float phvl_list[average_count] = {0, };
uint16_t tdsv_list[average_count] = {0, };
uint16_t gasd_list[average_count] = {0, };
uint16_t flam_list[average_count] = {0, };
