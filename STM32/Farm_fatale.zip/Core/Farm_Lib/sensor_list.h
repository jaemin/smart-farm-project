/*
 * sensor_list.h
 *
 *  Created on: Sep 22, 2026
 *      Author: Jaemin Joo
 */

#ifndef __SENSOR_LIST__
#define __SENSOR_LIST__

#include <stdint.h>

#define sensor_count	10
#define average_count	10

extern const char sensor[sensor_count][5];

extern float temp_list[average_count];
extern uint16_t humi_list[average_count];
extern uint16_t luxv_list[average_count];
extern float watp_list[average_count];
extern float flow_list[average_count];
extern float levl_list[average_count];
extern float phvl_list[average_count];
extern uint16_t tdsv_list[average_count];
extern uint16_t gasd_list[average_count];
extern uint16_t flam_list[average_count];

typedef enum {
	temp = 0,
	humi,
	luxv,
	watp,
	flow,
	levl,
	phvl,
	tdsv,
	gasd,
	flam
}sensor_name;

#endif /* __SENSOR_LIST__ */
