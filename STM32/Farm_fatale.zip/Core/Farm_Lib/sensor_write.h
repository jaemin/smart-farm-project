/*
 * sensor_write.h
 *
 *  Created on: Sep 23, 2026
 *      Author: Jaemin Joo
 */

#ifndef __SENSOR_WRITE__
#define __SENSOR_WRITE__

#include <string.h>
#include <main.h>
#include <usart.h>
#include <sensor_list.h>
#include <My_ARM_RTOS_Value_Lib_V1_4.h>
#include <ds18b20_custom.h>
#include <sensor_range.h>
#include <step_motor.h>

extern uint8_t buf[50];
extern uint8_t temp_fan_flag;
extern uint8_t humi_fan_flag;

extern void sensor_write_float(float result, int number);
extern void sensor_write_int(uint16_t result, int number);
extern void sensor_write();
extern float sensor_average_float(float* result);
extern uint16_t sensor_average_int(uint16_t* result);
extern void change_actuator_temp(float avg);
extern void change_actuator_humi_luxv(uint16_t avg_h, uint16_t avg_l);

#endif /* __SENSOR_WRITE__ */
