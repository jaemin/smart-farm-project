/*
 * message.h
 *
 *  Created on: Sep 30, 2026
 *      Author: PC
 */

#ifndef __MESSAGE__
#define __MESSAGE__

#include <stdint.h>
#include <string.h>
#include <main.h>

extern char recvMsg[20];
extern char* msg1, msg2, actuator_str, value_str;
extern uint8_t actuator, value;

void message_split(uint8_t* data[20]);

#endif /* FARM_LIB_MESSAGE_H_ */
