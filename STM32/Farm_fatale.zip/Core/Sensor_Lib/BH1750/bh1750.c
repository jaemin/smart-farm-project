/*
 * bh1750.c
 *
 *  Created on: Sep 23, 2026
 *      Author: Sunny
 */

#include <bh1750.h>
#include <sensor_write.h>

// BH1750 조도 센서
void BH1750_Read(void)
{
	uint8_t cmd = 0x10;
	HAL_I2C_Master_Transmit(&hi2c1, 0x23 << 1, &cmd, 1, 100);
	HAL_Delay(180);

	uint8_t data[2];
	HAL_I2C_Master_Receive(&hi2c1, 0x23 << 1, data, 2, 100);

	uint16_t lux = (data[0] << 8) | data[1];

	luxv_list[tm->min] = lux;

#ifdef DEBUG1
	printf("luxv%d : %d\r\n", tm->min, luxv_list[tm->min]);
#endif
}
