/*
 * bh1750.h
 *
 *  Created on: Sep 23, 2026
 *      Author: Sunny
 */

#ifndef SENSOR_LIB_BH1750_BH1750_H_
#define SENSOR_LIB_BH1750_BH1750_H_

#include <stdint.h>
#include <string.h>
#include <main.h>
#include <usart.h>
#include <i2c.h>

void BH1750_Read(void);

#endif /* SENSOR_LIB_BH1750_BH1750_H_ */
