/*
 * step_motor.h
 *
 *  Created on: Sep 30, 2026
 *      Author: Sunny, Jaemin Joo
 */

#ifndef __STEP_MOTOR__
#define __STEP_MOTOR__

#include <stdint.h>
#include <string.h>
#include <main.h>
#include <tim.h>
#include <My_ARM_RTOS_Value_Lib_V1_4.h>

#define	steps	60000			// 커튼의 길이에 따라 조절 (max : 65531)

extern int8_t step_phase;
extern uint8_t step_dir;
extern uint16_t motor_count;

// 스텝 모터 시퀀스
extern const uint8_t HALF_STEP_SEQ[8];

void stepper_run();
void stepper_control(uint8_t step);

#endif /* SENSOR_LIB_STEP_MOTOR_STEP_MOTOR_H_ */
