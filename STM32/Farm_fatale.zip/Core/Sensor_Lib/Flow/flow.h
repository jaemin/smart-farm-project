/*
 * flow.h
 *
 *  Created on: Sep 23, 2026
 *      Author: Sunny
 */

#ifndef __FLOW__
#define __FLOW__

#include <stdint.h>
#include <string.h>
#include <main.h>

extern float flow_lpm;
extern volatile uint32_t flow_pulse_count;

// 유량 센서 EXTI 콜백
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin);
void flow_read();

#endif /* SENSOR_LIB_FLOW_FLOW_H_ */
