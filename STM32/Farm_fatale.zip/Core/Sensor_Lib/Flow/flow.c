/*
 * flow.c
 *
 *  Created on: Sep 23, 2026
 *      Author: Sunny
 */

#include <flow.h>
#include <sensor_write.h>

float flow_lpm = 0;
volatile uint32_t flow_pulse_count = 0;

// 유량 센서 EXTI 콜백
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	if(GPIO_Pin == FLOW_Pin) // 또는 GPIO_PIN_0
	{
		flow_pulse_count++;
	}
}

// 유량 센서 측정
void flow_read() {
	// YF-S201 공식: F(Hz) = 7.5 * Q(L/min) : 데이터 시트 참조
#ifdef DEBUG1
	printf("pulse count : %d\r\n", flow_pulse_count);
#endif
	flow_lpm = ((float)flow_pulse_count / 6.0f) / 7.5f;
	flow_pulse_count = 0;

	flow_list[tm->min] = flow_lpm;
#ifdef DEBUG1
	printf("flow%d : %.2f\r\n", tm->min, flow_list[tm->min]);
#endif
}
