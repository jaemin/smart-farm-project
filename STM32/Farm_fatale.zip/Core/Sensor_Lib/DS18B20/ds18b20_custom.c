/*
 * ds18b20_custom.c
 *
 *  Created on: Sep 21, 2026
 *      Author: Jaemin Joo
 */

#include <ds18b20_custom.h>
#include <sensor_write.h>

ds18b20_t ds18;
ow_init_t ow_init_struct;
int16_t temp_c = 0;
uint8_t error_count = 0;

void ds18_tim_cb(TIM_HandleTypeDef *htim)
{
    ow_callback(&ds18.ow);
}
void ds18_done_cb(ow_err_t error)
{

}

void ds18b20_init_set(){
	ow_init_struct.tim_handle = &htim6;
	ow_init_struct.gpio = GPIOC;
    ow_init_struct.pin = GPIO_PIN_8;
    ow_init_struct.tim_cb = ds18_tim_cb;
    ow_init_struct.done_cb = NULL;   // Optional
    ow_init_struct.rom_id_filter = DS18B20_ID;

    ds18b20_init(&ds18, &ow_init_struct);

    // Update ROM IDs for all devices
    ds18b20_update_rom_id(&ds18);
    while(ds18b20_is_busy(&ds18));

    // Configure alarm thresholds and resolution
    ds18b20_config_t ds18_conf = {
        .alarm_high = 50,
        .alarm_low = -50,
        .cnv_bit = DS18B20_CNV_BIT_12
    };
    ds18b20_conf(&ds18, &ds18_conf);
    while(ds18b20_is_busy(&ds18));
}

void ds18b20_get(){
	float result = 0;

	ds18b20_cnv(&ds18);
	while(ds18b20_is_busy(&ds18));
	while(!ds18b20_is_cnv_done(&ds18));

	ds18b20_req_read(&ds18, 0);
	while(ds18b20_is_busy(&ds18));
	temp_c = ds18b20_read_c(&ds18);

	if(temp_c == DS18B20_ERROR) {		// 통신 에러
		printf("DS18B20 Error\r\n");
		printf("DS18B20 read retrying\r\n");
		error_count++;

		// 오류 연속 3번 이상 발생 시, 온도값 0으로 설정
		if(error_count >= 3) {
			error_count = 0;
			watp_list[tm->min] = 0;
#ifdef DEBUG1
	printf("watp%d : %.2f\r\n", tm->min, watp_list[tm->min]);
#endif
			return;
		}
		else {
			ds18b20_get();
		}
	}
	else{
		// 오류 카운트 초기화
		error_count = 0;
		// 온도 소수점 출력으로 변경하기
		result = (temp_c / 100) + (temp_c % 100) * 0.01;
		watp_list[tm->min] = result;
#ifdef DEBUG1
	printf("watp%d : %.2f\r\n", tm->min, watp_list[tm->min]);
#endif
	}
}
