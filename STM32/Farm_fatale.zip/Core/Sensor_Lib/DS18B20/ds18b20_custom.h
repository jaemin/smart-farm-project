/*
 * ds18b20_custom.h
 *
 *  Created on: Sep 21, 2026
 *      Author: Jaemin Joo
 */

#ifndef __DS18B20_CUSTOM__
#define __DS18B20_CUSTOM__

#include <string.h>
#include <main.h>
#include <ds18b20.h>
#include <ow.h>

extern ds18b20_t ds18;
extern ow_init_t ow_init_struct;
extern int16_t temp_c;
extern uint8_t error_count;

void ds18_tim_cb(TIM_HandleTypeDef *htim);
void ds18_done_cb(ow_err_t error);
void ds18b20_init_set();
void ds18b20_get();

#endif /* SENSOR_DS18B20_DS18B20_CUSTOM_H_ */
