/*
 * sht31.h
 *
 *  Created on: Sep 23, 2026
 *      Author: Sunny
 */

#ifndef __SHT31__
#define __SHT31__

#include <stdint.h>
#include <string.h>
#include <main.h>
#include <usart.h>
#include <i2c.h>
#include <sensor_write.h>

// SHT31 온습도 센서
void SHT31_Read();

#endif /* SENSOR_LIB_SHT31_SHT31_H_ */
