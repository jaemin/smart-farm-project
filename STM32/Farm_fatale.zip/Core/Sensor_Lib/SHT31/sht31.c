/*
 * sht31.c
 *
 *  Created on: Sep 23, 2026
 *      Author: Sunny
 */

#include <sht31.h>

void SHT31_Read()
{
	float temperature;
	uint16_t humidity;

	uint8_t cmd[2] = {0x24, 0x00};
	HAL_I2C_Master_Transmit(&hi2c1, 0x45 << 1, cmd, 2, 100);
	HAL_Delay(15);

	uint8_t data[6];
	HAL_I2C_Master_Receive(&hi2c1, 0x45 << 1, data, 6, 100);

	uint16_t rawTemp = (data[0] << 8) | data[1];
	uint16_t rawHum  = (data[3] << 8) | data[4];

	temperature = -45 + 175 * ((float)rawTemp / 65535.0);
	humidity  = (uint16_t)(100.0f * ((float)rawHum / 65535.0f));

	temp_list[tm->min] = temperature;
	humi_list[tm->min] = humidity;

#ifdef DEBUG1
	printf("temp%d : %.2f\r\n", tm->min, temp_list[tm->min]);
	printf("humi%d : %d\r\n", tm->min, humi_list[tm->min]);
#endif
}
