/*
 * adc.c
 *
 *  Created on: Sep 23, 2026
 *      Author: Sunny
 */

#include <adc_sensor.h>

uint16_t adc_buf[4];
uint16_t flame_raw;  	// PA1 불꽃
uint16_t ph_raw;  		// PA4 pH
uint16_t tds_raw;  		// PA6 TDS
uint16_t gas_raw;  		// PA7 가스

float ph_voltage;
float tds_voltage;
float ph_raw_calc;
float ph_value;
float ph_filtered = 0.0f;
uint16_t tds_ppm;

// 1) 구간별 보정 : 산성, 중성, 알칼리성
float ph_calibration(float ph)
{
	if (ph < 5.5f) return 0.10f; 		// 산성
	else if (ph < 8.5f) return 0.20f;	// 중성
	else return 0.15f;					// 알칼리성
}

// 2) Low-pass filter
float ph_lowpass_filter(float prev, float current, float alpha)
{
	return prev + alpha * (current - prev);
}

void adc_sensor_read() {
	flame_raw = adc_buf[0];
	ph_raw    = adc_buf[1];
	tds_raw   = adc_buf[2];
	gas_raw   = adc_buf[3];

	ph_voltage  = ph_raw  * (3.3f / 4095.0f);
	tds_voltage = tds_raw * (3.3f / 4095.0f);

#ifdef DEBUG1
	printf("PH RAW : %d\r\n", ph_raw);
#endif

//	ph_raw_calc = 7.0f + ((ph_voltage - 2.5f) * 3.3f);
//	ph_value = 4.01f + ((ph_raw_calc - 4.4f) / 0.2333f);

	// ※수정 및 추가_pH 센서 구문
	if (ph_voltage < 1.850f) // 1.850f : 약 4.5pH
	{
		// 산성
		ph_value = 7.00f + ((ph_voltage - 1.950f) * 15.528f);
	}
	else if (ph_voltage > 2.100f)
	{
		// 알칼리성
		ph_value = 7.00f + ((ph_voltage - 1.950f) * 12.097f);
	}
	else
	{
		// 중성
		ph_value = 7.00f + ((ph_voltage - 1.950f) * 5.000f);
	}

	// 4) 범위 제한 (Clamping)
	if (ph_value < 0.00f)  ph_value = 0.00f;
	if (ph_value > 14.00f) ph_value = 14.00f;

	// 5) LPF 필터 적용 (최초 시작 시 0.0V에서 시동되는 현상 방지)
	if (ph_filtered == 0.0f)
	{
		ph_filtered = ph_value; // 첫 실행 시 초기값 동기화
	}
	else
	{
		float alpha = ph_calibration(ph_value);
		ph_filtered = ph_lowpass_filter(ph_filtered, ph_value, alpha);
	}

	tds_ppm = (tds_voltage * 1000) / 2;

	phvl_list[tm->min] = ph_value;
	tdsv_list[tm->min] = tds_ppm;
	flam_list[tm->min] = flame_raw;
	gasd_list[tm->min] = gas_raw;
#ifdef DEBUG1
	printf("phvl%d : %.2f\r\n", tm->min, phvl_list[tm->min]);
	printf("tdsv%d : %d\r\n", tm->min, tdsv_list[tm->min]);
	printf("flam%d : %d\r\n", tm->min, flam_list[tm->min]);
	printf("gasd%d : %d\r\n", tm->min, gasd_list[tm->min]);
#endif
}
