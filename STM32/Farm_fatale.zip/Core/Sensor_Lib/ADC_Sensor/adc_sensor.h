/*
 * adc.h
 *
 *  Created on: Sep 23, 2026
 *      Author: Sunny
 */

#ifndef SENSOR_LIB_ADC_SENSOR_ADC_SENSOR_H_
#define SENSOR_LIB_ADC_SENSOR_ADC_SENSOR_H_

#include <main.h>
#include <sensor_write.h>

extern uint16_t adc_buf[4];
extern uint16_t flame_raw;  // PA1 불꽃
extern uint16_t ph_raw;  	// PA4 pH
extern uint16_t tds_raw;  	// PA6 TDS
extern uint16_t gas_raw;  	// PA7 가스

extern float ph_voltage;
extern float tds_voltage;
extern float ph_raw_calc;
extern float ph_value;
extern float ph_filtered;
extern uint16_t tds_ppm;

void adc_sensor_read();

#endif /* SENSOR_LIB_ADC_SENSOR_ADC_SENSOR_H_ */
